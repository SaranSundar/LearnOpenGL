#version 330 core
out vec4 LightColor;

void main()
{
    LightColor = vec4(1.0);
}